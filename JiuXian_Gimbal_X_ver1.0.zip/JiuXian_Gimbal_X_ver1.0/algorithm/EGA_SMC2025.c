#include "EGA_SMC2025.h"

static float Sat(float y)
{
		if (fabs(y) <= 1)
			return y;
		else
			return Signal(y);
}

static int8_t Signal(float y)
{
		if (y > 0)
			return 1;
		else if (y == 0)
			return 0;
		else
			return -1;
}

void EGA_SMC2025_init(EGA_SMC2025 *smc ,float C,float K,float ref,float error_eps,float u_max,float J,float epsilon){
    smc->C = C;
    smc->K = K;
    smc->ref = ref;
    smc->error_eps = error_eps;
    smc->u_max = u_max;
    smc->J = J;
    smc->epsilon = epsilon;
}

void EGA_SMC2026_Update(EGA_SMC2025 *smc, float angle_now,float angle_vel) //anlge为当前位置(°),ang_vel为角速度(°/s)
{
	//读取参数
	smc->angle = angle_now;
    smc->ang_vel = angle_vel;
	smc->error = smc->angle - smc->ref;
    if(smc->error > 180){
        smc->error -= 360;
    }else if(smc->error < -180){
        smc->error += 360;
    }

	smc->ddref = (smc->ref - smc->refl) - smc->dref; //这里对前馈进行了处理，没有严格单位统一
	smc->dref = (smc->ref - smc->refl);
	//误差下限处理
	if (fabs(smc->error) < smc->error_eps)
	{
		smc->u = 0;
		return;
	}
	//smc surface
	smc->s = smc->C * smc->error + (smc->ang_vel - smc->dref);
	smc->u = smc->J * (smc->ddref - smc->C * (smc->ang_vel - smc->dref) - smc->epsilon * Sat(smc->s) - smc->K * smc->s);
	//控制量限幅
	if (smc->u > smc->u_max)
		smc->u = smc->u_max;
	if (smc->u < -smc->u_max)
		smc->u = -smc->u_max;
	//参数更新
	smc->refl = smc->ref;
}

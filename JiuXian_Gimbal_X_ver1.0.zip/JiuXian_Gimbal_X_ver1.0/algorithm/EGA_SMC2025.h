#ifndef __EGA_SMC2025_H_
#define __EGA_SMC2025_H_

#ifdef __cplusplus
extern "C" {
#endif
	
#include "main.h"
#include "math.h"

typedef struct
{
    float C;
	float K;
	float ref; //初始目标值
	float error_eps;//误差下限
	float u_max;//输出最大值
	float J;//估计惯量
	float angle; //角度反馈，°
	float ang_vel;//角速度反馈，°/s
	float epsilon;

	float u;

    float error;
	float error_last;
	float dref;//目标值一阶导
	float ddref;//目标值二阶导
	float refl;//上一次的目标值

	float s;//滑模面
}EGA_SMC2025;

static float Sat(float y);
static int8_t Signal(float y);
void EGA_SMC2025_init(EGA_SMC2025 *smc ,float C,float K,float ref,float error_eps,float u_max,float J,float epsilon);
void EGA_SMC2026_Update(EGA_SMC2025 *smc, float angle_now,float angle_vel);

#ifdef __cplusplus
}
#endif	

#endif

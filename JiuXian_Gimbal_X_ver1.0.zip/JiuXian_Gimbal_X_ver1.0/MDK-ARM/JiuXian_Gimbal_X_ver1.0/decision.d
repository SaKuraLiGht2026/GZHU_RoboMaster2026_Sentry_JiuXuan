jiuxian_gimbal_x_ver1.0/decision.o: ..\Logic\decision.c \
  ..\Logic\decision.h

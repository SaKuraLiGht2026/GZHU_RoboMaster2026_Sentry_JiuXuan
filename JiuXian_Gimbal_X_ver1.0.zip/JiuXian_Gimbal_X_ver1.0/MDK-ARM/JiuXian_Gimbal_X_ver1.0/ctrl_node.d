jiuxian_gimbal_x_ver1.0/ctrl_node.o: ..\node\ctrl_node.c \
  ..\node\ctrl_node.h \
  ..\Drivers\CMSIS\Device\ST\STM32F4xx\Include\stm32f4xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32F4xx\Include\stm32f427xx.h \
  ..\Drivers\CMSIS\Include\core_cm4.h \
  ..\Drivers\CMSIS\Device\ST\STM32F4xx\Include\system_stm32f4xx.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal.h \
  ..\Core\Inc\stm32f4xx_hal_conf.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_rcc.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_def.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_rcc_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_gpio.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_gpio_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_exti.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_dma.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_dma_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_cortex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_can.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_flash.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_flash_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_flash_ramfunc.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_pwr.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_pwr_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_tim.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_tim_ex.h \
  ..\Drivers\STM32F4xx_HAL_Driver\Inc\stm32f4xx_hal_uart.h \
  ..\Core\Inc\can.h ..\Core\Inc\main.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\FreeRTOS.h \
  ..\Core\Inc\FreeRTOSConfig.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\projdefs.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\portable.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\deprecated_definitions.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\portable\RVDS\ARM_CM4F\portmacro.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\mpu_wrappers.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\task.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\list.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\CMSIS_RTOS_V2\cmsis_os2.h \
  ..\bsp\bsp_can.h ..\bsp\Flysky_bsp.h \
  ..\Middlewares\ST\ARM\DSP\Inc\arm_math.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h ..\drv\DJI_drv.h \
  ..\bsp\bsp_wit.h ..\Core\Inc\usart.h ..\Core\Inc\dma.h \
  ..\Logic\auto_mode.h ..\node\master_node.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\queue.h \
  ..\bsp\MiniPC.h ..\CRC\CRC16.h ..\CRC\CRC_table.h \
  ..\floatUnpack\IEEE754.h ..\algorithm\Ramp.h ..\algorithm\smc.h \
  ..\algorithm\pid.h ..\algorithm\lpf.h ..\algorithm\NLADRC_ver1.h

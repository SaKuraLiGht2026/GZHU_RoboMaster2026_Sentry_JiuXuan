jiuxian_gimbal_x_ver1.0\startup_stm32f427xx.o: startup_stm32f427xx.s

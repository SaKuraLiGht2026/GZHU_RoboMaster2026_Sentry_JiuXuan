#include "DJI_drv.h"

DJI_StatusType Steer_Ctrl(int16_t u1, int16_t u2, int16_t u3, int16_t u4)
{
     CAN_TxHeaderTypeDef tx_header;
     uint8_t             tx_data[8];

     tx_header.StdId = 0x1fe;
     tx_header.IDE   = CAN_ID_STD;
     tx_header.RTR   = CAN_RTR_DATA;
     tx_header.DLC   = 8;    

     tx_data[0] = u1 >> 8 & 0xff;
     tx_data[1] = u1      & 0xff;
     tx_data[2] = u2 >> 8 & 0xff;
     tx_data[3] = u2      & 0xff;
     tx_data[4] = u3 >> 8 & 0xff;
     tx_data[5] = u3      & 0xff;
     tx_data[6] = u4 >> 8 & 0xff;
     tx_data[7] = u4      & 0xff;

     if(HAL_CAN_AddTxMessage(&hcan1, &tx_header, tx_data, (uint32_t*)CAN_TX_MAILBOX0) != HAL_OK)
     {
         return DJI_ERROR;
     }else{
         return DJI_OK;
     }
}

DJI_StatusType Wheel_Ctrl(int16_t u1, int16_t u2, int16_t u3, int16_t u4)
{
     CAN_TxHeaderTypeDef tx_header;
     uint8_t             tx_data[8];

     tx_header.StdId = 0x200;
     tx_header.IDE   = CAN_ID_STD;
     tx_header.RTR   = CAN_RTR_DATA;
     tx_header.DLC   = 8;

     tx_data[0] = u1 >> 8 & 0xff;
     tx_data[1] = u1      & 0xff;
     tx_data[2] = u2 >> 8 & 0xff;
     tx_data[3] = u2      & 0xff;
     tx_data[4] = u3 >> 8 & 0xff;
     tx_data[5] = u3      & 0xff;
     tx_data[6] = u4 >> 8 & 0xff;
     tx_data[7] = u4      & 0xff;

     if(HAL_CAN_AddTxMessage(&hcan2, &tx_header, tx_data, (uint32_t*)CAN_TX_MAILBOX1) != HAL_OK)
     {
         return DJI_ERROR;
     }else{
         return DJI_OK;
     }
}

#ifndef __DJI_DRV_H_
#define __DJI_DRV_H_

#ifdef __cplusplus
extern "C" {
#endif
	
#include "stm32f4xx.h"
#include "can.h"

#define  DJI_StatusType  uint8_t

#define  DJI_OK          0x01
#define  DJI_ERROR       0x00

DJI_StatusType Steer_Ctrl(int16_t u1, int16_t u2, int16_t u3, int16_t u4);
DJI_StatusType Wheel_Ctrl(int16_t u1, int16_t u2, int16_t u3, int16_t u4);

#ifdef __cplusplus
}
#endif


#endif

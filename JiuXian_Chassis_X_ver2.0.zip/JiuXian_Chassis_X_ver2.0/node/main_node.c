#include "main_node.h"
#include "tim.h"
#include "usart.h"
#include "dma.h"
#include "FreeRTOS.h"
#include "cmsis_os2.h"
#include "task.h"
#include "queue.h"

#include "bsp_sentry_uart.h"

extern DMA_HandleTypeDef   hdma_usart2_rx;
extern DMA_HandleTypeDef   hdma_usart6_rx;

sentry_chassis_cmd_t       CPU_X_cmd;

void master_node(void *argument)
{
  /* USER CODE BEGIN master_node */
  __HAL_DMA_DISABLE_IT(&hdma_usart2_rx,DMA_IT_HT);
  __HAL_DMA_DISABLE_IT(&hdma_usart6_rx,DMA_IT_HT);
  HAL_UARTEx_ReceiveToIdle_DMA(&huart2, CPU_X_cmd.rx_buffer, sizeof(CPU_X_cmd.rx_buffer));
  /* Infinite loop */
  for(;;)
  {
    HAL_UARTEx_ReceiveToIdle_DMA(&huart2, CPU_X_cmd.rx_buffer, sizeof(CPU_X_cmd.rx_buffer));
    osDelay(1);
  }
  /* USER CODE END master_node */
}

void Power_Planner_node(void *argument)
{
  /* USER CODE BEGIN Power_Planner_node */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END Power_Planner_node */
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef * huart, uint16_t Size)
{
  if(huart->Instance == USART2)
  {
    sentry_uart_data_process(&CPU_X_cmd, CPU_X_cmd.rx_buffer);
    HAL_UARTEx_ReceiveToIdle_DMA(&huart2, CPU_X_cmd.rx_buffer, sizeof(CPU_X_cmd.rx_buffer));
    __HAL_DMA_DISABLE_IT(&hdma_usart2_rx,DMA_IT_HT);
  }
  if(huart->Instance == USART6)
  {
    __HAL_DMA_DISABLE_IT(&hdma_usart6_rx,DMA_IT_HT);
  }
}

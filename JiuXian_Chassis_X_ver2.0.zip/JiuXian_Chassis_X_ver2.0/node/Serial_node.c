#include "Serial_node.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os2.h"
#include "SerialPlot.h"

#include "bsp_sentry_uart.h"
#include "bsp_can.h"

#include "main_node.h"
#include "ctrl_node.h"

extern sentry_chassis_cmd_t       CPU_X_cmd;
extern Motor_info_t               wheel_info[4];
extern Motor_info_t               steer_info[4];

void Serial_node(void *argument)
{
  /* USER CODE BEGIN Serial_node */
  /* Infinite loop */
  for(;;)
  {
		VofaTenDataChannel(               CPU_X_cmd.steer[0],
										  CPU_X_cmd.steer[1],
										  CPU_X_cmd.steer[2],
										  CPU_X_cmd.steer[3],
										  steer_info[0].real_info.angle,
										  steer_info[1].real_info.angle,
										  steer_info[2].real_info.angle,
										  steer_info[3].real_info.angle,
										  NULL,
										  NULL
		);
    taskYIELD();
  }
  /* USER CODE END Serial_node */
}

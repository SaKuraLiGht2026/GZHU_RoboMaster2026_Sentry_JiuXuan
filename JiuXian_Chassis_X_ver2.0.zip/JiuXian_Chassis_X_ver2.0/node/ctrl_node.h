#ifndef __CTRL_NODE_H_
#define __CTRL_NODE_H_

#ifdef __cplusplus
extern "C" {
#endif
	
static float wheel_speed_transform(float AGV_Sentry_RM2026_SetSpeed);
static float steer_angle_transform(float AGV_Sentry_RM2026_SetAngel, float init_angle);

#ifdef __cplusplus
}
#endif

#endif

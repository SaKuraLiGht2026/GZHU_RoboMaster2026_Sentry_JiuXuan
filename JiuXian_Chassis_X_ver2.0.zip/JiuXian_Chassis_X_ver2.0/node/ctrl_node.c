#include "ctrl_node.h"
#include "tim.h"
#include "FreeRTOS.h"
#include "cmsis_os2.h"
#include "task.h"
#include "queue.h"
#include "bsp_sentry_uart.h"
#include "bsp_can.h"
#include "DJI_drv.h"

#include "pid.h"
#include "smc.h"

#define  MOTOR_TEST_MODE_START 0

#define AGV_Sentry_Wheel_Radius    0.058  //0.058m

extern sentry_chassis_cmd_t       CPU_X_cmd;

Motor_info_t                      wheel_info[4];
Motor_info_t                      steer_info[4];

int16_t                           wheel_current[4] = {0};
int16_t                           steer_current[4] = {0};

PID_param_t                       wheel_pid[4];
smc_param_t                       steer_smc[4];
LowPassFilter1p_Info_TypeDef      steer_ntsmc_lpf[4];

void Ctrl_node(void *argument)
{
  /* USER CODE BEGIN Ctrl_node */
  float Steer_init_angle[4] = {
                                256.408264f,
                                103.240143f,
                                191.229401f,
                                161.211090f
                              };

  PID_init(&wheel_pid[0], 360, 10, 40, 0.1, 1000, 6000);
  PID_init(&wheel_pid[1], 360, 10, 40, 0.1, 1000, 6000);
  PID_init(&wheel_pid[2], 360, 10, 40, 0.1, 1000, 6000);
  PID_init(&wheel_pid[3], 360, 10, 40, 0.1, 1000, 6000);

  ntsmc_init(&steer_smc[0].ntsmc_t);
  ntsmc_init(&steer_smc[1].ntsmc_t);
  ntsmc_init(&steer_smc[2].ntsmc_t);
  ntsmc_init(&steer_smc[3].ntsmc_t);

  smc_init(&steer_smc[0], 3600);
  smc_init(&steer_smc[1], 3600);
  smc_init(&steer_smc[2], 3600);
  smc_init(&steer_smc[3], 3600);

  ntsmc_param_set(&steer_smc[0].ntsmc_t, 1000, 0.0024, 5, 0.5, 15, 13, 5, 3, 0.341, 1.1);
  ntsmc_param_set(&steer_smc[1].ntsmc_t, 1000, 0.0024, 5, 0.5, 15, 13, 5, 3, 0.341, 1.1);
  ntsmc_param_set(&steer_smc[2].ntsmc_t, 1000, 0.0024, 5, 0.5, 15, 13, 5, 3, 0.341, 1.1);
  ntsmc_param_set(&steer_smc[3].ntsmc_t, 1000, 0.0024, 5, 0.5, 15, 13, 5, 3, 0.341, 1.1);
  /* Infinite loop */
  for(;;)
  {
    taskENTER_CRITICAL();
    /* 进入临界区 */
    wheel_current[0] = (int16_t)PID_Calc(&wheel_pid[0], wheel_speed_transform(CPU_X_cmd.wheel[0] / AGV_Sentry_Wheel_Radius), wheel_info[0].real_info.speed);
    wheel_current[1] = (int16_t)PID_Calc(&wheel_pid[1], wheel_speed_transform(CPU_X_cmd.wheel[1] / AGV_Sentry_Wheel_Radius), wheel_info[1].real_info.speed);
    wheel_current[2] = (int16_t)PID_Calc(&wheel_pid[2], wheel_speed_transform(CPU_X_cmd.wheel[2] / AGV_Sentry_Wheel_Radius), wheel_info[2].real_info.speed);
    wheel_current[3] = (int16_t)PID_Calc(&wheel_pid[3], wheel_speed_transform(CPU_X_cmd.wheel[3] / AGV_Sentry_Wheel_Radius), wheel_info[3].real_info.speed);

    SMC_Update(&steer_smc[0], steer_angle_transform(CPU_X_cmd.steer[0], Steer_init_angle[0]), steer_info[0].real_info.angle, steer_info[0].real_info.speed, NTSMC);
    SMC_Update(&steer_smc[1], steer_angle_transform(CPU_X_cmd.steer[1], Steer_init_angle[1]), steer_info[1].real_info.angle, steer_info[1].real_info.speed, NTSMC);
    SMC_Update(&steer_smc[2], steer_angle_transform(CPU_X_cmd.steer[2], Steer_init_angle[2]), steer_info[2].real_info.angle, steer_info[2].real_info.speed, NTSMC);
    SMC_Update(&steer_smc[3], steer_angle_transform(CPU_X_cmd.steer[3], Steer_init_angle[3]), steer_info[3].real_info.angle, steer_info[3].real_info.speed, NTSMC);

    steer_current[0] = (int16_t)steer_smc[0].u;
    steer_current[1] = (int16_t)steer_smc[1].u;
    steer_current[2] = (int16_t)steer_smc[2].u;
    steer_current[3] = (int16_t)steer_smc[3].u;

    #if MOTOR_TEST_MODE_START
    wheel_current[0] = 0;
    wheel_current[1] = 0;
    wheel_current[2] = 0;
    wheel_current[3] = 0;

    steer_current[0] = 0;
    steer_current[1] = 0;
    steer_current[2] = 0;
    steer_current[3] = 0;
    #endif
    /* 退出临界区 */
    taskEXIT_CRITICAL();
    //osDelay(1);
    taskYIELD();
  }
  /* USER CODE END Ctrl_node */
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  if (htim->Instance == TIM1)
  {
		 if(Steer_Ctrl(
                    steer_current[0], 
                    steer_current[1], 
                    steer_current[2], 
                    steer_current[3]
                  )              
                  == DJI_OK
       )
		 {
		    
		 }
     //…………………………………………………………do something…………………………………………………………//
	}
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM2)
  {
    Wheel_Ctrl(
                    wheel_current[0], 
                    wheel_current[1],
                    wheel_current[2],
                    wheel_current[3]
                  )
                  ;
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
  CAN_RxHeaderTypeDef rx_header;
  uint8_t rx_data[8];

  if(hcan->Instance == CAN1)
  {
      HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_11);
      HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data);

      switch(rx_header.StdId)
      {
            case GM6020_ID1 :
            {
                                steer_info[0].motorType = GM6020;
                                Motor_info_Updata(&steer_info[0], rx_data);
                                break;
            }
            case GM6020_ID2 :
            {
                                steer_info[1].motorType = GM6020;
                                Motor_info_Updata(&steer_info[1], rx_data);
                                break;
            }
            case GM6020_ID3 :
            {
                                steer_info[2].motorType = GM6020;
                                Motor_info_Updata(&steer_info[2], rx_data);
                                break;
            }
            case GM6020_ID4 :
            {
                                steer_info[3].motorType = GM6020;
                                Motor_info_Updata(&steer_info[3], rx_data);
                                break;
            }
            default         :
            {
                                break;
            }
      }
  }
}

void HAL_CAN_RxFifo1MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
   CAN_RxHeaderTypeDef rx_header;
   uint8_t rx_data[8];

   if(hcan->Instance == CAN2)
   {
       HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_14);
       HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO1, &rx_header, rx_data);

       switch(rx_header.StdId)
       {
             case M3508_ID1 :
             {
                                 wheel_info[0].motorType = M3508;
                                 Motor_info_Updata(&wheel_info[0], rx_data);
                                 break;
             }
             case M3508_ID2 :
             {
                                 wheel_info[1].motorType = M3508;
                                 Motor_info_Updata(&wheel_info[1], rx_data);
                                 break;
             }
             case M3508_ID3 :
             {
                                 wheel_info[2].motorType = M3508;
                                 Motor_info_Updata(&wheel_info[2], rx_data);
                                 break;
             }
             case M3508_ID4 :
             {
                                 wheel_info[3].motorType = M3508;
                                 Motor_info_Updata(&wheel_info[3], rx_data);
                                 break;
             }
             default         :
             {
                                 break;
             }
       }
		}
}

static float wheel_speed_transform(float AGV_Sentry_RM2026_SetSpeed)
{
    return -AGV_Sentry_RM2026_SetSpeed;
}

static float steer_angle_transform(float AGV_Sentry_RM2026_SetAngel, float init_angle)
{
    float angle = AGV_Sentry_RM2026_SetAngel + init_angle;
    return (angle > 360? angle - 360 : (angle < 0? angle + 360 : angle));
}


#ifndef __BSP_SENTRY_UART_H_
#define __BSP_SENTRY_UART_H_

#ifdef __cplusplus
extern "C" {
#endif
	
#include "stm32f4xx.h"
#include "usart.h"
#include "dma.h"

#define POS_MAX          180.0f
#define SPD_MAX            0.8f       //  m/s

#define UART_SEND_OK     0x01
#define UART_SEND_ERR    0x00

#define UART_RECEIVE_OK  0x01
#define UART_RECEIVE_ERR 0x00

typedef struct {
	float wheel[4];
    float steer[4];

    uint8_t rx_buffer[20];
}sentry_chassis_cmd_t;	

typedef struct {
    float wheel[4];
    float steer[4];

    uint8_t tx_buffer[20];
}sentry_chassis_send_cmd_t;;

static int float_to_uint(float x, float x_min, float x_max, uint8_t bits);
static float uint_to_float(int X_int, float X_min, float X_max, int Bits);

uint8_t sentry_uart_data_process(sentry_chassis_cmd_t *cmd, uint8_t *data);
uint8_t sentry_chassis_data_feedback(float *wheel, float *steer);

#ifdef __cplusplus
}
#endif

#endif

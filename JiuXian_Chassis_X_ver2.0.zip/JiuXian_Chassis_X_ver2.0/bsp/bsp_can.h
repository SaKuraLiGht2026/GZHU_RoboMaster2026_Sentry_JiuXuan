#ifndef __BSP_CAN_H_
#define __BSP_CAN_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include "can.h"	

#define GM6020          0xAA
#define M3508           0xBB

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define M3508_ID1       0x201
#define M3508_ID2       0x202
#define M3508_ID3       0x203
#define M3508_ID4       0x204

#define GM6020_ID1      0x205
#define GM6020_ID2      0x206
#define GM6020_ID3      0x207
#define GM6020_ID4      0x208

#define Wheel_1         M3508_ID1
#define Wheel_2         M3508_ID2
#define Wheel_3         M3508_ID3
#define Wheel_4         M3508_ID4

#define Steer_1         GM6020_ID1
#define Steer_2         GM6020_ID2
#define Steer_3         GM6020_ID3
#define Steer_4         GM6020_ID4

#define Current_MAX_Enc 16384
#define Current_MAX     20.0f


/* USER CODE END PD */

typedef struct
{
    uint16_t angle_enc;
    int16_t  speed_enc;
    int16_t  torque_enc;
    int16_t  temp;
}Motor_info_enc;

typedef struct
{
    float angle;
    float speed;
    float torqueCurrent;
    float temp;
}Motor_info_real;

typedef struct
{
    Motor_info_enc  enc_info;
    Motor_info_real real_info;
    uint8_t         motorType;
    uint8_t         motor_FSM;

    uint32_t        Ctrl_Freq;
}Motor_info_t;
	
void can1_filter_init(void);
void can2_filter_init(void);	

void Motor_info_Updata(Motor_info_t *motor, uint8_t data[8]);
static void enc2real(Motor_info_t *motor);
	
#ifdef __cplusplus
}
#endif


#endif	
	
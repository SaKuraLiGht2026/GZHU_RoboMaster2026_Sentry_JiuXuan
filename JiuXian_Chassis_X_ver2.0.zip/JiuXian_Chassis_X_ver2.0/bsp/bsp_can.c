#include "bsp_can.h"

void can1_filter_init(void)
{
    CAN_FilterTypeDef can_filter;

    can_filter.FilterBank = 0;
    can_filter.FilterMode = CAN_FILTERMODE_IDMASK;
    can_filter.FilterScale = CAN_FILTERSCALE_32BIT;
    can_filter.FilterIdHigh = 0x0000;
    can_filter.FilterIdLow = 0x0000;
    can_filter.FilterMaskIdHigh = 0x0000;
    can_filter.FilterMaskIdLow = 0x0000;
    can_filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    can_filter.FilterActivation = ENABLE;
    can_filter.SlaveStartFilterBank = 14;

    HAL_CAN_ConfigFilter(&hcan1, &can_filter);
    HAL_CAN_Start(&hcan1);
    HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

}

void can2_filter_init(void)
{
    CAN_FilterTypeDef can_filter;
		
	can_filter.FilterBank = 14;                  
    can_filter.FilterMode = CAN_FILTERMODE_IDMASK;
    can_filter.FilterScale = CAN_FILTERSCALE_32BIT;
    can_filter.FilterIdHigh = 0x0000;       
    can_filter.FilterIdLow = 0x0000;
    can_filter.FilterMaskIdHigh = 0x0000;
    can_filter.FilterMaskIdLow = 0x0000;
    can_filter.FilterFIFOAssignment = CAN_FILTER_FIFO1;
    can_filter.FilterActivation = ENABLE;
	
    HAL_CAN_ConfigFilter(&hcan2, &can_filter);  
    HAL_CAN_Start(&hcan2);                       
	//   HAL_CAN_ActivateNotification(&hcan2, CAN_IT_RX_FIFO0_MSG_PENDING);
	HAL_CAN_ActivateNotification(&hcan2, CAN_IT_RX_FIFO1_MSG_PENDING);
}

void Motor_info_Updata(Motor_info_t *motor, uint8_t data[8])
{
    motor ->enc_info.angle_enc    = (data[0] << 8) | data[1];
    motor ->enc_info.speed_enc    = (data[2] << 8) | data[3];
    motor ->enc_info.torque_enc   = (data[4] << 8) | data[5];
    motor ->enc_info.temp         =  data[6];
    enc2real(motor);
}

static void enc2real(Motor_info_t *motor)
{
    switch (motor ->motorType)
    {
        case M3508  : {
                        motor ->real_info.angle         = motor ->enc_info.angle_enc  *      360.0f /         8191.0f ;
                        motor ->real_info.speed         = motor ->enc_info.speed_enc  /(      19.0f *           9.55f);
                        motor ->real_info.torqueCurrent = motor ->enc_info.torque_enc * Current_MAX / Current_MAX_Enc ;       
                        motor ->real_info.temp          = motor ->enc_info.temp       *        1.0f /            1.0f ;
                        break;
        }
        case GM6020 : {
                        motor ->real_info.angle         = motor ->enc_info.angle_enc  *      360.0f /         8191.0f ;
                        motor ->real_info.speed         = motor ->enc_info.speed_enc  *        1.0f /           9.55f ;
                        motor ->real_info.torqueCurrent = motor ->enc_info.torque_enc * Current_MAX / Current_MAX_Enc ;
                        motor ->real_info.temp          = motor ->enc_info.temp       *        1.0f /            1.0f ;
                        break;
        }
    }
}


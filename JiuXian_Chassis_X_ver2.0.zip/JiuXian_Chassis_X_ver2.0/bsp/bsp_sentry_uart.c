#include "bsp_sentry_uart.h"

static int float_to_uint(float x, float x_min, float x_max, uint8_t bits)
{
    float span = x_max - x_min;
    float offset = x_min;
    return (int) ((x-offset)*((float)((1<<bits)-1))/span);
}

static float uint_to_float(int X_int, float X_min, float X_max, int Bits)
{	
    float span = X_max - X_min;
    float offset = X_min;
    return ((float)X_int)*span/((float)((1<<Bits)-1)) + offset;
}

uint8_t sentry_uart_data_process(sentry_chassis_cmd_t *cmd, uint8_t *data)
{
    uint8_t CheckSum  = data[2] + data[3] + data[4] + data[5] + data[6] + data[7] + data[8] + data[9] + data[10] + data[11] + data[12] + data[13] + data[14] + data[15] + data[16] + data[17];

    if(data[0] != 0xAA)//校验帧头
    {
        return UART_RECEIVE_ERR;
    }else{
        if(data[1] != 0x55)//校验帧头
        {
            return UART_RECEIVE_ERR;
        }else{
            if(data[18] != CheckSum)//校验和
            {
                return UART_RECEIVE_ERR;
            }else{
                if(data[19] != 0xFF)//校验帧尾
                {
                    return UART_RECEIVE_ERR;
                }else{
                    uint16_t vel_uint[4];
                    uint16_t ang_uint[4];

                    vel_uint[0] = data[2]  << 8 | data[3];
                    vel_uint[1] = data[4]  << 8 | data[5];
                    vel_uint[2] = data[6]  << 8 | data[7];
                    vel_uint[3] = data[8]  << 8 | data[9];
                    ang_uint[0] = data[10] << 8 | data[11];
                    ang_uint[1] = data[12] << 8 | data[13];
                    ang_uint[2] = data[14] << 8 | data[15];
                    ang_uint[3] = data[16] << 8 | data[17];

                    cmd ->wheel[0] = uint_to_float(vel_uint[0], -SPD_MAX, SPD_MAX, 16);
                    cmd ->wheel[1] = uint_to_float(vel_uint[1], -SPD_MAX, SPD_MAX, 16);
                    cmd ->wheel[2] = uint_to_float(vel_uint[2], -SPD_MAX, SPD_MAX, 16);
                    cmd ->wheel[3] = uint_to_float(vel_uint[3], -SPD_MAX, SPD_MAX, 16);
                    cmd ->steer[0] = uint_to_float(ang_uint[0], -POS_MAX, POS_MAX, 16);
                    cmd ->steer[1] = uint_to_float(ang_uint[1], -POS_MAX, POS_MAX, 16);
                    cmd ->steer[2] = uint_to_float(ang_uint[2], -POS_MAX, POS_MAX, 16);
                    cmd ->steer[3] = uint_to_float(ang_uint[3], -POS_MAX, POS_MAX, 16);

                    return UART_RECEIVE_OK;
                }
            }
        }
    }
}

uint8_t sentry_chassis_data_feedback(float *wheel, float *steer)
{
    uint8_t tx_data[20];

    uint16_t WHEEL[4];
    uint16_t STEER[4];

    WHEEL[0] = float_to_uint(wheel[0], -SPD_MAX, SPD_MAX, 16);
    WHEEL[1] = float_to_uint(wheel[1], -SPD_MAX, SPD_MAX, 16);
    WHEEL[2] = float_to_uint(wheel[2], -SPD_MAX, SPD_MAX, 16);
    WHEEL[3] = float_to_uint(wheel[3], -SPD_MAX, SPD_MAX, 16);
    STEER[0] = float_to_uint(steer[0], -POS_MAX, POS_MAX, 16);
    STEER[1] = float_to_uint(steer[1], -POS_MAX, POS_MAX, 16);
    STEER[2] = float_to_uint(steer[2], -POS_MAX, POS_MAX, 16);

    uint8_t CheckSum;//数据段校验和

    tx_data[2]  = (WHEEL[0] >> 8) & 0xFF;
    tx_data[3]  =  WHEEL[0]       & 0xFF;
    tx_data[4]  = (WHEEL[1] >> 8) & 0xFF;
    tx_data[5]  =  WHEEL[1]       & 0xFF;
    tx_data[6]  = (WHEEL[2] >> 8) & 0xFF;
    tx_data[7]  =  WHEEL[2]       & 0xFF;
    tx_data[8]  = (WHEEL[3] >> 8) & 0xFF;
    tx_data[9]  =  WHEEL[3]       & 0xFF;
    tx_data[10] = (STEER[0] >> 8) & 0xFF;
    tx_data[11] =  STEER[0]       & 0xFF;
    tx_data[12] = (STEER[1] >> 8) & 0xFF;
    tx_data[13] =  STEER[1]       & 0xFF;
    tx_data[14] = (STEER[2] >> 8) & 0xFF;
    tx_data[15] =  STEER[2]       & 0xFF;
    tx_data[16] = (STEER[3] >> 8) & 0xFF;
    tx_data[17] =  STEER[3]       & 0xFF;

    tx_data[0] = 0x2B;
    tx_data[1] = 0x54;

    CheckSum = tx_data[2] + tx_data[3] + tx_data[4] + tx_data[5] + tx_data[6] + tx_data[7] + tx_data[8] + tx_data[9] + tx_data[10] + tx_data[11] + tx_data[12] + tx_data[13] + tx_data[14] + tx_data[15] + tx_data[16] + tx_data[17];

    tx_data[18] = CheckSum;
    tx_data[19] = 0xFF;

    if(HAL_UART_Transmit_DMA(&huart2, tx_data, sizeof(tx_data)) != HAL_OK)
    {
        return UART_SEND_ERR;
    }else{        
        return UART_SEND_OK;
    }
}
